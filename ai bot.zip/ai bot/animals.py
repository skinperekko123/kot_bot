import tf_keras as keras  # Импортируем tf-keras - это совместимая версия Keras для работы с .h5 моделями
from tf_keras.models import load_model  # Загружаем функцию load_model из tf_keras, чтобы открыть модель
from PIL import Image, ImageOps  # Installing pillow instead of PIL
import numpy as np
import telebot
# Замени 'TOKEN' на токен твоего бота
bot = telebot.TeleBot("8634124143:AAEHTaM23fGDPiymNz_s-MdXRQrtlSa4HeI")

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Я твой Telegram бот. Напиши команду /hello, /bye")

@bot.message_handler(commands=['hello'])
def send_hello(message):
    bot.reply_to(message, "Привет! Как дела?")

@bot.message_handler(commands=['bye'])
def send_bye(message):
    bot.reply_to(message, "Пока! Удачи!")

@bot.message_handler(content_types=['photo'])
def ai_photo(message):
    file_info = bot.get_file(message.photo[-1].file_id)
    file_name = file_info.file_path.split('/')[-1]
    downloaded_file = bot.download_file(file_info.file_path)
    with open(file_name, 'wb') as new_file:
        new_file.write(downloaded_file)
    np.set_printoptions(suppress=True)

    model = load_model("keras_model.h5", compile=False)
    classes = open("labels.txt", "r", encoding="utf-8").readlines()
    data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

    image = Image.open(file_name).convert("RGB")
    size = (224,224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)

    image_list = np.asarray(image)

    nia = (image_list.astype(np.float32)/ 127.5) - 1

    data[0] = nia
    prediction = model.predict(data)
    index = np.argmax(prediction)
    classs = classes[index]
    score = prediction[0][index]

    print("Class:", classs[2:], end="")
    print("Score:", score)

    bot.reply_to(message, "на картинке " + classs[2:] + "я уверен на " + str(score) + " процентов")

# Запускаем бота
bot.polling()